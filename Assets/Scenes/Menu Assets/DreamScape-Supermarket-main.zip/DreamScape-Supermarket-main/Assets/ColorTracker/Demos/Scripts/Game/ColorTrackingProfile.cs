using UnityEngine;

[CreateAssetMenu(menuName = "Tracking/Color Tracking Profile", fileName = "ColorTrackingProfile")]
public class ColorTrackingProfile : ScriptableObject
{
    [Header("HSV center [0..1]")]
    [Range(0, 1)] public float hCenter = 0.28f;
    [Range(0, 1)] public float sCenter = 0.80f;
    [Range(0, 1)] public float vCenter = 0.70f;

    [Header("HSV range [0..0.5]")]
    [Range(0, 0.5f)] public float hRange = 0.08f;
    [Range(0, 0.5f)] public float sRange = 0.35f;
    [Range(0, 0.5f)] public float vRange = 0.35f;

    public bool mirrorHorizontal = true;

    const string K = "CTP_";
    public void SaveToPrefs()
    {
        PlayerPrefs.SetFloat(K + "hC", hCenter);
        PlayerPrefs.SetFloat(K + "sC", sCenter);
        PlayerPrefs.SetFloat(K + "vC", vCenter);
        PlayerPrefs.SetFloat(K + "hR", hRange);
        PlayerPrefs.SetFloat(K + "sR", sRange);
        PlayerPrefs.SetFloat(K + "vR", vRange);
        PlayerPrefs.SetInt(K + "mir", mirrorHorizontal ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void LoadFromPrefs()
    {
        if (!PlayerPrefs.HasKey(K + "hC")) return;
        hCenter = PlayerPrefs.GetFloat(K + "hC", hCenter);
        sCenter = PlayerPrefs.GetFloat(K + "sC", sCenter);
        vCenter = PlayerPrefs.GetFloat(K + "vC", vCenter);
        hRange = PlayerPrefs.GetFloat(K + "hR", hRange);
        sRange = PlayerPrefs.GetFloat(K + "sR", sRange);
        vRange = PlayerPrefs.GetFloat(K + "vR", vRange);
        mirrorHorizontal = PlayerPrefs.GetInt(K + "mir", mirrorHorizontal ? 1 : 0) != 0;
    }
}
