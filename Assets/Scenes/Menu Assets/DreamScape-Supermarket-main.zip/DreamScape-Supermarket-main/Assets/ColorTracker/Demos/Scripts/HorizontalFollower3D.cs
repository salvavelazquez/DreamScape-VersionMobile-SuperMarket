using UnityEngine;

namespace Vexpot.Integration
{
    /// <summary>
    /// Mueve un objeto en X seg�n el centro de un TrackerResult.
    /// Mantiene fija la Y del objeto.
    /// </summary>
    [AddComponentMenu("Vexpot/HorizontalFollower3D")]
    public class HorizontalFollower3D : MonoBehaviour
    {
        [Header("Referencias")]
        public ColorTrackerPanel trackerPanel;
        public Transform follower;                 // el objeto a mover (si null usa transform)

        [Header("Configuraci�n")]
        public int trackedIndex = 0;               // �ndice del target a seguir (0 si solo hay uno)
        public bool smooth = true;
        public float smoothSpeed = 10f;            // mayor = m�s r�pido
        public float? fixedYOverride = null;       // opcional: fijar Y a este valor; si null usa la Y inicial

        private Camera _cam;
        private float _fixedY;
        private Vector3 _scratchScreen;            // reuso para evitar alloc

        void Awake()
        {
            _cam = Camera.main;
            if (follower == null) follower = transform;
            _fixedY = fixedYOverride.HasValue ? fixedYOverride.Value : follower.position.y;
            _scratchScreen = Vector3.zero;
        }

        void Update()
        {
            if (trackerPanel == null) return;
            var tracker = trackerPanel.GetColorTracker();
            if (tracker == null || !tracker.isRunning || Camera.main == null) return;

            var results = tracker.Compute();
            if (results == null || results.Count == 0) return;

            // Clamp por seguridad
            int idx = Mathf.Clamp(trackedIndex, 0, results.Count - 1);
            var target = results[idx];
            if (target.state != TrackingState.Tracked) return;

            // Convertimos centro (coordenadas de input) a coordenadas de pantalla
            CoordinateMapper.ConvertInputToScreen(tracker.input, target.center, ref _scratchScreen);

            // Usamos la Z del objeto para proyectar en mundo
            float currentZinScreen = _cam.WorldToScreenPoint(follower.position).z;
            _scratchScreen.z = currentZinScreen;

            Vector3 world = _cam.ScreenToWorldPoint(_scratchScreen);
            Vector3 desired = new Vector3(world.x, _fixedY, follower.position.z);

            follower.position = smooth
                ? Vector3.Lerp(follower.position, desired, Time.deltaTime * smoothSpeed)
                : desired;
        }
    }
}
