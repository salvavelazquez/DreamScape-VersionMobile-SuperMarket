using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ColorCalibrationController : MonoBehaviour, IPointerClickHandler
{
    [Header("UI")]
    public RawImage cameraView;
    public Dropdown cameraDropdown;
    public Toggle mirrorToggle;
    public Text hsvText; // opcional

    [Header("Perfil")]
    public ColorTrackingProfile profile; // arrastr� tu asset aqu�

    [Header("Webcam")]
    [Tooltip("Solo se usa como fallback si el arranque por nombre no entrega frames.")]
    public int requestedWidth = 640, requestedHeight = 480, requestedFPS = 30;

    WebCamTexture camTex;
    bool mirror = true;

    void Start()
    {
        StartCoroutine(InitCalibration());
    }

    void OnDestroy()
    {
        if (camTex != null)
        {
            camTex.Stop();
            Destroy(camTex);
            camTex = null;
        }
    }

    IEnumerator InitCalibration()
    {
        // Cargar preferencias del perfil y espejo
        if (profile != null) profile.LoadFromPrefs();
        mirror = profile != null ? profile.mirrorHorizontal : true;

        // Permisos
        if (!Application.HasUserAuthorization(UserAuthorization.WebCam))
            yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);

        // Poblar dropdown
        var devices = WebCamTexture.devices;
        cameraDropdown.ClearOptions();
        cameraDropdown.AddOptions(devices.Select(d => d.name).ToList());
        cameraDropdown.onValueChanged.AddListener(i => StartCoroutine(StartSelectedCameraCo(i)));

        // Toggle espejo
        mirrorToggle.isOn = mirror;
        mirrorToggle.onValueChanged.AddListener(v =>
        {
            mirror = v;
            if (cameraView != null)
                cameraView.uvRect = mirror ? new Rect(1, 0, -1, 1) : new Rect(0, 0, 1, 1);
        });

        // Elegir default: primera �real� si existe
        int startIndex = 0;
        for (int i = 0; i < devices.Length; i++)
        {
            var n = devices[i].name.ToLower();
            if (!n.Contains("obs") && !n.Contains("virtual")) { startIndex = i; break; }
        }

        if (devices.Length > 0)
        {
            cameraDropdown.value = Mathf.Clamp(startIndex, 0, devices.Length - 1);
            yield return StartCoroutine(StartSelectedCameraCo(cameraDropdown.value));
        }
        else
        {
            Debug.LogWarning("[Calibration] No se detectaron c�maras.");
        }
    }

    IEnumerator StartSelectedCameraCo(int index)
    {
        // Apagar anterior si existe
        if (camTex != null)
        {
            camTex.Stop();
            Destroy(camTex);
            camTex = null;
        }

        var devices = WebCamTexture.devices;
        if (devices == null || devices.Length == 0) yield break;

        index = Mathf.Clamp(index, 0, devices.Length - 1);
        string name = devices[index].name;

        // 1) Intento �suave�: nombre solo (deja que negocie formato)
        camTex = new WebCamTexture(name);
        camTex.Play();

        bool ok = false;
        yield return StartCoroutine(WaitForFirstFrame(camTex, 3f, r => ok = r));

        if (!ok)
        {
            // 2) Fallback: forzar preset pedido
            Debug.LogWarning($"[Calibration] {name} no entreg� frames con preset libre. Probando fallback {requestedWidth}x{requestedHeight}@{requestedFPS}...");
            camTex.Stop();
            Destroy(camTex);

            camTex = new WebCamTexture(name, requestedWidth, requestedHeight, requestedFPS);
            camTex.Play();

            ok = false;
            yield return StartCoroutine(WaitForFirstFrame(camTex, 3f, r => ok = r));

            if (!ok)
            {
                Debug.LogError($"[Calibration] {name} no entreg� frames (�OBS Virtual Camera iniciada? �Otra app usando la c�mara?).");
                camTex.Stop();
                Destroy(camTex);
                camTex = null;
                yield break;
            }
        }

        // Mostrar directo la WebCamTexture en el RawImage
        cameraView.texture = camTex;
        cameraView.uvRect = mirror ? new Rect(1, 0, -1, 1) : new Rect(0, 0, 1, 1);
        FitRawImage(cameraView, camTex.width, camTex.height);
    }

    // Corrutina que �devuelve� bool v�a callback
    IEnumerator WaitForFirstFrame(WebCamTexture tex, float timeoutSeconds, Action<bool> done)
    {
        float t0 = Time.realtimeSinceStartup;
        while (Time.realtimeSinceStartup - t0 < timeoutSeconds)
        {
            if (tex != null && tex.didUpdateThisFrame && tex.width > 16 && tex.height > 16)
            {
                done?.Invoke(true);
                yield break;
            }
            yield return null;
        }
        done?.Invoke(false);
    }

    public void RefreshCameras()
    {
        var devices = WebCamTexture.devices;
        cameraDropdown.ClearOptions();
        cameraDropdown.AddOptions(devices.Select(d => d.name).ToList());
    }

    void Update()
    {
        // Si alg�n d�a necesit�s l�gica por frame:
        // if (camTex != null && camTex.isPlaying && camTex.didUpdateThisFrame) { ... }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (camTex == null || !camTex.isPlaying) return;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(cameraView.rectTransform, eventData.position, null, out var local))
            return;

        var rect = cameraView.rectTransform.rect;
        if (!rect.Contains(local)) return;

        // Letterbox/pillarbox en el RawImage
        float texW = camTex.width, texH = camTex.height;
        float rectW = rect.width, rectH = rect.height;
        float arTex = texW / texH, arRect = rectW / rectH;

        float drawnW, drawnH, xOff, yOff;
        if (arTex > arRect) { drawnW = rectW; drawnH = rectW / arTex; xOff = 0; yOff = (rectH - drawnH) * 0.5f; }
        else { drawnH = rectH; drawnW = rectH * arTex; yOff = 0; xOff = (rectW - drawnW) * 0.5f; }

        float px = local.x - (rect.xMin + xOff);
        float py = local.y - (rect.yMin + yOff);
        if (px < 0 || py < 0 || px > drawnW || py > drawnH) return;

        float u = px / drawnW;
        float v = py / drawnH;
        if (mirror) u = 1f - u;

        int tx = Mathf.Clamp(Mathf.RoundToInt(u * (camTex.width - 1)), 0, camTex.width - 1);
        int ty = Mathf.Clamp(Mathf.RoundToInt(v * (camTex.height - 1)), 0, camTex.height - 1);

        var c = camTex.GetPixel(tx, ty);
        Color.RGBToHSV(c, out float H, out float S, out float V);

        if (profile != null)
        {
            profile.hCenter = H; profile.sCenter = S; profile.vCenter = V;
            profile.hRange = 0.08f;
            profile.sRange = Mathf.Clamp01(Mathf.Max(0.2f, 0.5f - S * 0.3f));
            profile.vRange = Mathf.Clamp01(Mathf.Max(0.2f, 0.5f - V * 0.3f));
            profile.mirrorHorizontal = mirror;
        }

        if (hsvText != null)
            hsvText.text = $"HSV: {H:F2}, {S:F2}, {V:F2}";
    }

    public void OnSaveAndBack()
    {
        if (profile != null) profile.SaveToPrefs();
        SceneManager.LoadScene("Menu");
    }

    void FitRawImage(RawImage img, int texW, int texH)
    {
        var rt = img.rectTransform;
        var canvas = img.canvas;
        float cw = canvas ? canvas.pixelRect.width : Screen.width;
        float ch = canvas ? canvas.pixelRect.height : Screen.height;

        float arTex = (float)texW / texH;
        float arCanvas = cw / ch;

        if (arTex > arCanvas) rt.sizeDelta = new Vector2(cw, cw / arTex);
        else rt.sizeDelta = new Vector2(ch * arTex, ch);
    }
}
