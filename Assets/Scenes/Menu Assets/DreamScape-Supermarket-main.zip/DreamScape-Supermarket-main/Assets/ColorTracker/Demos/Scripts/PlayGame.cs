using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayGame : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public string Game;
    public void LoadScene()
    {
        SceneManager.LoadScene(Game);
    }
}
