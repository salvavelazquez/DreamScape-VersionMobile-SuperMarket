using UnityEngine;
using System.Collections.Generic;
using Vexpot;                 // ColorTarget
using Vexpot.Integration;     // ColorTrackerPanel / Renderer

public class ApplyColorProfileToVexpot_NoCreate : MonoBehaviour
{
    [Header("Entrada")]
    public ColorTrackingProfile profile;           // tu asset con HSV guardado (Calibration)
    public ColorTrackerPanel panel;                // arrastr� tu panel aqu�
    public ColorTrackerRenderer rendererOptional;  // opcional: espejo

    [Header("Comportamiento")]
    public bool restartTracker = true;             // Stop/Start para aplicar cambios
    public bool applyMirrorToRenderer = true;      // setear mirrorHorizontal en renderer
    public bool verbose = false;

    [Header("Tolerance (fija)")]
    [Range(10f, 50f)] public float desiredTolerance = 13.2f;  // <- pon� 13.2

    void Awake()
    {
        if (panel == null) panel = GetComponent<ColorTrackerPanel>();
        if (profile == null || panel == null)
        {
            Debug.LogWarning("[ApplyProfileToVexpot_NoCreate_Strict] Falta profile o panel.");
            return;
        }

        // 1) cargar HSV del perfil
        profile.LoadFromPrefs();

        // 2) (opcional) espejo en el renderer
        if (applyMirrorToRenderer && rendererOptional != null)
            rendererOptional.mirrorHorizontal = profile.mirrorHorizontal;

        // 3) tomar lista existente (no crear nada nuevo)
        List<ColorTarget> list = panel.colorTargets;
        if (list == null || list.Count == 0)
        {
            Debug.LogError("[ApplyProfileToVexpot_NoCreate_Strict] No hay ColorTargets en el panel. Agreg� 1 en el Inspector y volv� a ejecutar.");
            return;
        }

        // 4) convertir HSV -> RGB del perfil
        Color rgb = Color.HSVToRGB(profile.hCenter, profile.sCenter, profile.vCenter);

        // 5) usar tolerance fija = 13.2 (clamp 10�50)
        float tol = Mathf.Clamp(desiredTolerance, 10f, 50f);

        // 6) editar el PRIMER target existente
        var ct = list[0];
        ct.color = rgb;
        ct.tolerance = tol;

        if (verbose) Debug.Log($"[ApplyProfileToVexpot_NoCreate_Strict] color={rgb} tolerance={tol:F1}");

        // 7) notificar al panel
        panel.UpdateColorTargets();

        // 8) reiniciar si corresponde
        if (restartTracker)
        {
            panel.StopColorTracker();
            StartCoroutine(RestartNextFrame());
        }
    }

    System.Collections.IEnumerator RestartNextFrame()
    {
        yield return null; // esperar un frame
        panel.StartColorTracker();
    }
}
