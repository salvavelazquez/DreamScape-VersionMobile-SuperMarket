using UnityEngine;

[AddComponentMenu("Vexpot/CubeHorizontalFollower")]
public class CubeHorizontalFollower : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("RectTransform del puntero UI (si no lo asignas, se buscar� autom�ticamente).")]
    public RectTransform pointerUI;

    [Tooltip("C�mara que renderiza tu escena 3D. Si no asignas, usa Camera.main.")]
    public Camera sceneCamera;

    [Header("B�squeda del puntero (auto-rebind)")]
    [Tooltip("Tag del puntero (recomendado si pod�s taggear el prefab).")]
    public string pointerTag = "TrackerPointer";
    [Tooltip("Si no hay tag, buscar por nombre que contenga este texto (ej: 'indicator').")]
    public string pointerNameContains = "indicator";
    [Tooltip("Canvas donde aparece el indicador (opcional, acelera la b�squeda).")]
    public Canvas searchInCanvas;
    [Tooltip("Cada cu�ntos segundos reintentar encontrar el puntero cuando falta.")]
    public float rebindInterval = 0.3f;

    [Header("Movimiento")]
    [Range(0f, 1f)] public float smooth = 0.25f;
    public bool clampToScreen = true;
    public float screenMarginPx = 8f;

    [Header("Debug")]
    public bool debugLogs = false;

    // Cache
    Canvas _pointerCanvas;
    Camera _uiCamera;     // c�mara del Canvas si NO es Overlay
    float _fixedY;
    Rigidbody _rb;
    float _nextFindTime = 0f;

    void Awake()
    {
        _fixedY = transform.position.y;
        _rb = GetComponent<Rigidbody>();
        if (sceneCamera == null) sceneCamera = Camera.main;
        if (sceneCamera == null)
        {
            Debug.LogError("[CubeHorizontalFollower] No hay Camera asignada ni Camera.main en escena.");
            enabled = false;
            return;
        }
    }

    void OnEnable()
    {
        // Intento inicial de cachear c�mara de canvas si ya est� asignado
        if (pointerUI != null) CacheCanvasCamera(pointerUI);
        _nextFindTime = 0f; // permitir b�squeda inmediata si falta
    }

    void Update()
    {
        // Auto-rebind si el puntero desapareci� (lo destruy� el tracker al perder color)
        if (!IsPointerValid())
        {
            TryRebindPointer();
            return; // hasta volver a encontrarlo no movemos
        }

        // 1) Pos del puntero en pantalla
        Vector2 pointerScreen = RectTransformUtility.WorldToScreenPoint(_uiCamera, pointerUI.position);

        // 2) Z de pantalla del cubo (profundidad relativa a la c�mara)
        Vector3 cubeScreen = sceneCamera.WorldToScreenPoint(transform.position);
        if (cubeScreen.z <= 0.001f) cubeScreen.z = Mathf.Max(sceneCamera.nearClipPlane + 0.1f, 0.5f);

        // 3) Clamp horizontal en espacio de pantalla
        float minX = screenMarginPx;
        float maxX = Screen.width - screenMarginPx;
        float targetScreenX = clampToScreen ? Mathf.Clamp(pointerScreen.x, minX, maxX) : pointerScreen.x;

        // 4) Convertir a mundo a esa profundidad
        Vector3 targetWorld = sceneCamera.ScreenToWorldPoint(new Vector3(targetScreenX, cubeScreen.y, cubeScreen.z));

        // 5) Mover solo X (Y fijo, Z intacto)
        Vector3 pos = transform.position;
        float k = 1f - Mathf.Pow(1f - Mathf.Clamp01(smooth), Time.deltaTime * 60f);
        pos.x = Mathf.Lerp(pos.x, targetWorld.x, k);
        pos.y = _fixedY;

        if (_rb != null && !_rb.isKinematic) _rb.MovePosition(pos);
        else transform.position = pos;

        if (debugLogs && Time.frameCount % 20 == 0)
            Debug.Log($"[Follower] ptrX={pointerScreen.x:F1} cubeZ={cubeScreen.z:F2} worldX={targetWorld.x:F2}");
    }

    bool IsPointerValid()
    {
        // es v�lido si existe y est� activo en la jerarqu�a
        return pointerUI != null && pointerUI.gameObject != null && pointerUI.gameObject.activeInHierarchy;
    }

    void TryRebindPointer()
    {
        if (Time.unscaledTime < _nextFindTime) return;
        _nextFindTime = Time.unscaledTime + Mathf.Max(0.05f, rebindInterval);

        // 1) por TAG (el m�s robusto si pod�s taggear el prefab del indicador)
        if (!string.IsNullOrEmpty(pointerTag))
        {
            var go = GameObject.FindWithTag(pointerTag);
            if (go != null && go.activeInHierarchy)
            {
                var rt = go.GetComponent<RectTransform>();
                if (rt != null)
                {
                    pointerUI = rt;
                    CacheCanvasCamera(pointerUI);
                    if (debugLogs) Debug.Log("[CubeHorizontalFollower] Rebind por TAG: " + go.name);
                    return;
                }
            }
        }

        // 2) por nombre que contenga (ej. "Indicator(Clone)")
        string needle = (pointerNameContains ?? "").ToLower();
        if (!string.IsNullOrEmpty(needle))
        {
            RectTransform found = null;

            if (searchInCanvas != null)
            {
                foreach (var rt in searchInCanvas.GetComponentsInChildren<RectTransform>(true))
                {
                    if (rt.gameObject.activeInHierarchy && rt.name.ToLower().Contains(needle))
                    { found = rt; break; }
                }
            }
            else
            {
                var all = GameObject.FindObjectsOfType<RectTransform>(true); // incluye inactivos
                foreach (var rt in all)
                {
                    if (rt.gameObject.activeInHierarchy && rt.name.ToLower().Contains(needle))
                    { found = rt; break; }
                }
            }

            if (found != null)
            {
                pointerUI = found;
                CacheCanvasCamera(pointerUI);
                if (debugLogs) Debug.Log("[CubeHorizontalFollower] Rebind por NOMBRE: " + found.name);
                return;
            }
        }

        // Si no lo encontr�, seguir� intentando cada rebindInterval
    }

    void CacheCanvasCamera(RectTransform rt)
    {
        var c = rt.GetComponentInParent<Canvas>();
        _pointerCanvas = c;
        _uiCamera = (c != null && c.renderMode != RenderMode.ScreenSpaceOverlay) ? c.worldCamera : null;
    }
}
