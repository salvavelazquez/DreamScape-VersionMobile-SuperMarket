﻿using UnityEngine;
using System.Collections.Generic;
using System;

namespace Vexpot.Integration
{
    /// <summary>
    /// Implements the tools for displaying the <see cref="TrackerResult"/> on Unity UI.
    /// </summary>
    [AddComponentMenu("Vexpot/ColorTrackerRenderer")]
    public class ColorTrackerRenderer : MonoBehaviour
    {
        /// <summary> The canvas to display the tracks. </summary>
        public Canvas canvas;
        /// <summary> The object used as pointer graphic. </summary>
        public GameObject graphicModel;
        /// <summary> A reference to the GameObject containing the tracker panel. </summary>
        public ColorTrackerPanel trackerPanel;

        // 👇 NUEVO: controles de espejado para corregir cámaras frontales
        [Header("Mapping overrides")]
        public bool mirrorHorizontal = true;   // True para webcams frontales (selfie)
        public bool mirrorVertical = false;    // Útil si alguna cam viene invertida en Y

        private ColorTracker _tracker;
        private List<GameObject> _graphics;
        private Vector3 _reusableScreenPosition;

        void Awake()
        {
            if (ValidateComponents())
            {
                _graphics = new List<GameObject>();
                _reusableScreenPosition = new Vector3();
            }
        }

        private bool ValidateComponents()
        {
            Camera cam = GetComponent<Camera>();
            if (cam == null || !cam.enabled)
            {
                Debug.LogError("OnPostRender no se llamará: falta un Camera activo en este GameObject.");
                return false;
            }

            if (Camera.main == null)
            {
                Debug.LogError("Debe existir al menos una cámara etiquetada como MainCamera.");
                return false;
            }

            if (trackerPanel == null)
            {
                Debug.LogError("Debes asignar un ColorTrackerPanel a este componente.");
                return false;
            }

            if (canvas == null)
            {
                Debug.LogError("Debes asignar el Canvas donde se dibujarán los tracks.");
                return false;
            }

            if (graphicModel == null)
            {
                Debug.LogError("Debes asignar el prefab gráfico que se usará como puntero.");
                return false;
            }

            return true;
        }

        private GameObject CreateGraphic()
        {
            GameObject obj = Instantiate(graphicModel) as GameObject;
            obj.transform.SetParent(canvas.transform, false);
            obj.SetActive(false);
            return obj;
        }

        private void DestroyPreviousGraphics()
        {
            if (_graphics == null) return;
            for (var gindex = 0; gindex < _graphics.Count; gindex++)
                Destroy(_graphics[gindex]);

            _graphics.Clear();
        }

        private void CreateNewGraphics(int count)
        {
            for (var gindex = 0; gindex < count; gindex++)
                _graphics.Add(CreateGraphic());
        }

        void OnDestroy()
        {
            DestroyPreviousGraphics();
        }

        void OnPostRender()
        {
            if (!trackerPanel) return;

            _tracker = trackerPanel.GetColorTracker();
            if (_tracker == null || Camera.main == null) return;

            if (!_tracker.isRunning)
            {
                DestroyPreviousGraphics();
                return;
            }

            List<TrackerResult> result = _tracker.Compute();

            if (_graphics == null) _graphics = new List<GameObject>();
            if (_graphics.Count != result.Count)
            {
                DestroyPreviousGraphics();
                CreateNewGraphics(result.Count);
            }

            for (var i = 0; i < result.Count; i++)
            {
                GameObject actual = _graphics[i];
                TrackerResult target = result[i];

                if (target.state == TrackingState.Tracked)
                {
                    // 1) De coordenadas del input a coordenadas de pantalla (pixeles)
                    CoordinateMapper.ConvertInputToScreen(_tracker.input, target.center, ref _reusableScreenPosition);

                    // 2) Corregir espejado según tu cámara
                    if (mirrorHorizontal)
                        _reusableScreenPosition.x = Screen.width - _reusableScreenPosition.x;

                    if (mirrorVertical)
                        _reusableScreenPosition.y = Screen.height - _reusableScreenPosition.y;

                    // 3) Pasar de pantalla a UI (RectTransform en el Canvas)
                    CoordinateMapper.ConvertScreenToUI(_reusableScreenPosition, actual.GetComponent<RectTransform>());

                    actual.SetActive(true);
                }
                else
                {
                    actual.SetActive(false);
                }
            }
        }
    }
}
